import React, { useEffect, useRef } from "react";
import Button from "@mui/material/Button";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import image from "./img/passportlogo-lion.png";
import axios from "axios";
import { Row, Col, ProgressBar, ListGroup } from "react-bootstrap";
import html2canvas from "html2canvas";

const UserHome = () => {
  const navigate = useNavigate();
  const [progress, setProgress] = useState("");
  const [photoUrl, setPhotoUrl] = useState("");
  const [userData, setUserData] = useState(null);
  const cardRef = useRef(null);

  useEffect(() => {
    fetchAllApplicationsDup();

    if (userData && userData.photo && userData.photo.data) {
      const byteArray = new Uint8Array(userData.photo.data);
      const blob = new Blob([byteArray], { type: "image/jpeg" }); // Adjust the type as necessary
      const url = URL.createObjectURL(blob);
      setPhotoUrl(url);
    }
  }, [userData?.photo]);

  // const callTiming = () => {
  //   setLoading(true);
  //   setTimeout(() => {
  //     setLoading(false);
  //   }, 2000);
  // };

  const handleDownloadPhoto = () => {
    if (cardRef.current) {
      html2canvas(cardRef.current).then((canvas) => {
        const link = document.createElement("a");
        link.href = canvas.toDataURL("image/png");
        link.download = "passport-card.png"; // Adjust filename and format as needed
        link.click();
      });
    }
  };

  const applyForPassport = () => {
    // Simulate applying process and updating the progress bar
    //   let newProgress = progress + 25;
    //   if (newProgress > 100) newProgress = 100;
    //   setProgress(newProgress);
    navigate("/applyform"); // Navigate to the dashboard after login
  };

  const fetchAllApplicationsDup = async () => {
    try {
      let response = await axios.get("http://localhost:5000/api/applications");
      setProgress(response.data[0].status);
      setUserData(response.data[0]);
      console.log("application response dup: " + JSON.stringify(response));
    } catch (error) {
      console.error("Error fetching applications dup:", error);
    }
  };
  return (
    <div className="container-custom">
      <div className="dashboard-header">
        <img src={image} />
        <h3>PASSPORT SEVA KENDRA</h3>
      </div>
      <a className="redirect1" href="/login">
        Click to logout
      </a>
      {progress != "" && (
        <div>
          <Row>
            <Col>
              <h4 className="text-center header-custom mb-3">
                Application Status - {`${progress}`}
              </h4>
            </Col>
          </Row>
        </div>
      )}
      {progress == "approved" && userData && (
        <div>
          <div ref={cardRef} className="passport">
            <div className="passport-header">
              <h1>Republic of India Passport</h1>
              <hr />
            </div>
            <div className="passport-body">
              <div className="passport-photo">
                {photoUrl && (
                  <img src={photoUrl} alt="User Photo" className="user-photo" />
                )}
              </div>
              <div className="passport-details">
                <h2>{userData.name}</h2>
                <p>
                  <strong>Date of Birth:</strong>{" "}
                  {new Date(userData.dob).toLocaleDateString()}
                </p>
                <p>
                  <strong>Mobile:</strong> {userData.mobile}
                </p>
                <p>
                  <strong>Email:</strong> {userData.email}
                </p>
                <p>
                  <strong>Aadhar:</strong> {userData.aadhar}
                </p>
              </div>
            </div>
          </div>
          <button onClick={handleDownloadPhoto} className="download-button">
            Click to download
          </button>
        </div>
      )}
      {progress == "" && (
        <div>
          <div className="step-details">
            <Row>
              <Col>
                <h2 className="text-center header-custom">
                  Steps to Apply for a Passport
                </h2>
                <ListGroup>
                  <ListGroup.Item>
                    1. Fill out the application form
                  </ListGroup.Item>
                  <ListGroup.Item>2. Submit required documents</ListGroup.Item>
                  <ListGroup.Item>3. Pay the application fee</ListGroup.Item>
                  <ListGroup.Item>
                    4. Schedule and attend an interview
                  </ListGroup.Item>
                  <ListGroup.Item>5. Wait for passport issuance</ListGroup.Item>
                </ListGroup>
              </Col>
            </Row>
          </div>
          <div>
            <button className="global-button" onClick={applyForPassport}>
              Click here to Apply
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserHome;
