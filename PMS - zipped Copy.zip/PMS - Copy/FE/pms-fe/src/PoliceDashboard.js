import React, { useEffect, useState } from "react";
import image from "./img/passportlogo-lion.png";
import axios from "axios";

export const PoliceDashboard = () => {
  const [applications, setApplications] = useState([]);
  const [highlighted, sethighlighted] = useState("all");
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState({
    all: 0,
    approved: 0,
    rejected: 0,
    processing: 0,
  });

  const fetchCounts = async () => {
    try {
      const response = await axios.get("http://localhost:5000/api/counts"); // Update with your actual endpoint
      setData(response.data);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    callTiming();
    fetchAllApplications();

    // Fetch data initially
    fetchCounts();

    // Set interval to fetch data every 3 seconds
    const interval = setInterval(fetchCounts, 5000);

    // Clear interval on component unmount
    return () => clearInterval(interval);
  }, []);

  const callTiming = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
    }, 2000);
  };

  const policeId = parseInt(localStorage.getItem("policeId"));

  const fetchAllApplications = async () => {
    sethighlighted("all");
    callTiming();
    try {
      const response = await axios.get(
        "http://localhost:5000/api/applications"
      );
      setApplications(response.data);
      console.log("application response: " + response.data);
    } catch (error) {
      console.error("Error fetching applications:", error);
    }
  };

  const fetchApprovedApplications = async () => {
    sethighlighted("approved");
    callTiming();
    try {
      const response = await axios.get(
        "http://localhost:5000/api/applications/approved"
      );
      setApplications(response.data);
      console.log("Approved applications response:", response.data);
    } catch (error) {
      console.error("Error fetching approved applications:", error);
    }
  };

  const fetchRejectedApplications = async () => {
    sethighlighted("rejected");
    callTiming();
    try {
      const response = await axios.get(
        "http://localhost:5000/api/applications/rejected"
      );
      setApplications(response.data);
      console.log("Rejected applications response:", response.data);
    } catch (error) {
      console.error("Error fetching rejected applications:", error);
    }
  };

  const fetchProcessingApplications = async () => {
    sethighlighted("processing");
    callTiming();
    try {
      const response = await axios.get(
        "http://localhost:5000/api/applications/processing"
      );
      setApplications(response.data);
      console.log("Processing applications response:", response.data);
    } catch (error) {
      console.error("Error fetching processing applications:", error);
    }
  };

  const handleApprove = async (id) => {
    try {
      await axios.post(`http://localhost:5000/api/approve`, {
        appId: id,
        policeId,
      });
      fetchApprovedApplications();
      setApplications(
        applications.map((app) =>
          app.id === id ? { ...app, status: "approved" } : app
        )
      );
    } catch (error) {
      console.error("Error approving application:", error);
    }
  };

  const handleReject = async (id) => {
    try {
      await axios.post(`http://localhost:5000/api/reject/`, {
        appId: id,
        policeId,
      });
      fetchRejectedApplications();
      setApplications(
        applications.map((app) =>
          app.id === id ? { ...app, status: "rejected" } : app
        )
      );
    } catch (error) {
      console.error("Error rejecting application:", error);
    }
  };

  return (
    <div className="policedashboardheader">
      <div>
        <h1 className="header">Police Verification</h1>
        <hr />
        <a href="/policeLogin">Click to logout</a>
      </div>
      <div className="container">
        <div className="application-card1">
          <div
            className={`cardDetails ${
              highlighted === "all" ? "highlighted" : ""
            }`}
            onClick={fetchAllApplications}
          >
            <h4>Total users : {data && data[0] ? data[0].all : "Loading..."}</h4>
          </div>
          <div
            className={`cardDetails ${
              highlighted === "approved" ? "highlighted" : ""
            }`}
            onClick={fetchApprovedApplications}
          >
            <h4>Approved users : {data && data[0] ? data[0].approved : "Loading..."}</h4>
          </div>
          <div
            className={`cardDetails ${
              highlighted === "rejected" ? "highlighted" : ""
            }`}
            onClick={fetchRejectedApplications}
          >
            <h4>Rejected users : {data && data[0] ? data[0].rejected : "Loading..."}</h4>
          </div>
          <div
            className={`cardDetails ${
              highlighted === "processing" ? "highlighted" : ""
            }`}
            onClick={fetchProcessingApplications}
          >
            <h4>Processing : {data && data[0] ? data[0].processing : "Loading..."}</h4>
          </div>
        </div>
        {loading && <div className="loading-overlay">Loading...</div>}
        {applications.map((application) => (
          <div className="application-card" key={application.id}>
            <div className="field">
              <span className="label">Name:</span>
              <span className="value">{application.name}</span>
            </div>
            <div className="field">
              <span className="label">Date of Birth:</span>
              <span className="value">{application.dob.substring(0, 10)}</span>
            </div>
            <div className="field">
              <span className="label">Mobile:</span>
              <span className="value">{application.mobile}</span>
            </div>
            <div className="field">
              <span className="label">Email:</span>
              <span className="value">{application.email}</span>
            </div>
            <div className="field">
              <span className="label">Aadhar:</span>
              <span className="value">{application.aadhar}</span>
            </div>
            {highlighted !== "approved" &&
              highlighted !== "rejected" &&
              highlighted !== "all" && (
                <div className="field">
                  <div>
                    <button
                      className="global-button1"
                      onClick={() => handleApprove(application.id)}
                    >
                      Approve
                    </button>
                    <button
                      className="global-button2"
                      onClick={() => handleReject(application.id)}
                    >
                      Reject
                    </button>
                  </div>
                </div>
              )}
            {highlighted == "all" && (
              <div className="field">
                <span className="label">Status:</span>
                <span className="value">{application.status}</span>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
