import logo from "./logo.svg";
import "./App.css";
import {
  BrowserRouter as Router,
  Route,
  Routes,
  useNavigate,
} from "react-router-dom";

import UserHome from "./UserHome";
import ApplyForm from "./ApplyForm";
import { PoliceDashboard } from "./PoliceDashboard";
import { useState } from "react";
import Login from "./Login";
import Signup from "./Signup";
import PoliceLogin from "./PoliceLogin";

function App() {
  const [authendicatedtoken, setAuthendicatedtoken] = useState(null);
  const [policeAuthendicatedtoken, setPoliceAuthendicatedtoken] =
    useState(null);

  const handleToken = (passToken) => {
    setAuthendicatedtoken(passToken);
  };

  const handlePoliceToken = (policepassToken) => {
    setPoliceAuthendicatedtoken(policepassToken);
  };

  return (
    <div className="App">
      <Router>
        <Routes>
          {authendicatedtoken ? (
            <>
              <Route path="/dashboard" element={<UserHome />} />
              <Route path="/applyform" element={<ApplyForm />} />
            </>
          ) : (
            <>
              <Route
                path="/login"
                element={<Login passToken={handleToken} />}
              />
              <Route path="/signup" element={<Signup />} />
            </>
          )}
          <Route
                path="*"
                element={<Login passToken={handleToken} />}
              />
          <Route
            path="/policeLogin"
            element={<PoliceLogin policepassToken={handlePoliceToken} />}
          />

          //police
          {policeAuthendicatedtoken ? (
            <Route path="/policeDashboard" element={<PoliceDashboard />} />
          ) : (
            <Route
              path="/policeLogin"
              element={<PoliceLogin policepassToken={handlePoliceToken} />}
            />
          )}
        </Routes>
      </Router>
    </div>
  );
}

export default App;
