import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const PoliceLogin = ({policepassToken}) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState(null);

  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    const loginData = {
      email: email,
      password: password,
    };

    try {
      const response = await axios.post(
        "http://localhost:5000/api/policelogin",
        loginData
      );
      console.log("Login successful:", response);
      policepassToken(response.data.token); // Set the token in the context
      localStorage.setItem('policeId',response.data.policeId);
      navigate('/policeDashboard');
      // Handle success (e.g., redirect to home page, save token, etc.)
    } catch (error) {
      console.error("There was an error during login:", error.response.data.message);
      setErr(error.response.data.message);
      // Handle error (e.g., display error message, etc.)
    }
  };

  return (
    <div className="signup-container">
      <form className="signup-form" onSubmit={handleSubmit}>
        <h2>Police Login</h2>
        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => (setEmail(e.target.value),setErr(null))}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => (setPassword(e.target.value),setErr(null))}
            required
          />
        </div>
        {err && <p>{err}</p>}
        <button type="submit" className="signup-button">
          Login
        </button>
        {/* <a className="redirect" href="/signup">
          Not a User? SignUp
        </a> */}
      </form>
    </div>
  );
};

export default PoliceLogin;
