import React from "react";
import { useState} from "react";
import axios from 'axios';
import { useNavigate } from "react-router-dom";


const ApplyForm = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: "",
    dob: "",
    mobile: "",
    email: "",
    aadhar: "",
    photo: null,
    marksheet: null,
    declaration: false,
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleFileChange = (e) => {
    const { name, files } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: files[0],
    }));
  };

  const handleNext = (e) => {
    e.preventDefault();
    setStep(step + 1);
  };

  const handleBack = (e) => {
    e.preventDefault();
    setStep(step - 1);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    let data = new FormData();
    data.append("name", formData.name);
    data.append("dob", formData.dob);
    data.append("mobile", formData.mobile);
    data.append("email", formData.email);
    data.append("aadhar", formData.aadhar);
    data.append("photo", formData.photo);
    data.append("marksheet", formData.marksheet);
    data.append("declaration", formData.declaration);
    data.append("userId",localStorage.getItem("userId"));

        // Log FormData content for debugging
        for (let pair of data.entries()) {
          console.log(`${pair[0]}, ${pair[1]}`);
        }

    try {
      const response = await axios.post("http://localhost:5000/api/applyPassport", data, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      alert("Form submitted successfully! ");
      navigate('/dashboard');
    } catch (error) {
      console.error("Error submitting the form:", error);
    }
  };

  return (
    <div className="applyform">
      <div className="form-container">
        {step === 1 && (
          <form onSubmit={handleNext}>
            <div>
              <h4>Step 1 of 2</h4>
              <h2>General Information</h2>
            </div>
            <div className="display-row">
              <div className="display-col">
                <div>
                  <label>Name:</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div>
                  <label>Date of Birth:</label>
                  <input
                    type="date"
                    name="dob"
                    value={formData.dob}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>
              <div className="display-col">
                <div>
                  <label>Mobile No:</label>
                  <input
                    type="text"
                    name="mobile"
                    value={formData.mobile}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div>
                  <label>Email:</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>
            </div>
            <div className="footer-button">
              <a href="#" onClick={() => navigate('/dashboard')}>Back to home</a>
              <button className="global-button" type="submit">
                Next
              </button>
            </div>
          </form>
        )}
        {step === 2 && (
          <form onSubmit={handleSubmit}>
            <div>
              <h4>Step 2 of 2</h4>
              <h2>General Information</h2>
            </div>
            <div className="display-row">
              <div className="display-col">
                <div>
                  <label>Aadhar no :</label>
                  <input
                    type="number"
                    name="aadhar"
                    value={formData.aadhar}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div>
                  <label>10th marksheet :</label>
                  <input
                    type="file"
                    name="marksheet"
                    onChange={handleFileChange}
                    required
                  />
                </div>
              </div>
              <div className="display-col">
                <div>
                  <label>Photo:</label>
                  <input
                    type="file"
                    name="photo"
                    onChange={handleFileChange}
                    required
                  />
                </div>
              </div>
            </div>
            <div>
              <label>
                <input
                  type="checkbox"
                  name="declaration"
                  checked={formData.declaration}
                  onChange={handleChange}
                  required
                />
                I hereby declare that the information provided is true and
                correct.
              </label>
            </div>
            <div className="footer-button">
              <button
                type="button"
                className="global-button"
                onClick={handleBack}
              >
                Previous
              </button>
              <button type="submit" className="global-button">
                Submit
              </button>
            </div>
          </form>
        )}
        {/* <div>
          <label>Upload File:</label>
          <input type="file" name="file" onChange={handleFileChange} required />
        </div> */}
        {/* <button type="submit">Submit</button> */}
      </div>
    </div>
  );
};

export default ApplyForm;
