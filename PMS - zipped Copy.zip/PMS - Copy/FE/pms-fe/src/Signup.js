import React, { useState } from 'react'
import axios from 'axios';


const Signup = () => {
    const [username, setUsername] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
  
    const handleSubmit = async (e) => {
      e.preventDefault();
      // Handle signup logic here

      const signupData = {
        username: username,
        email: email,
        password: password
      };
  
      try {
        const response = await axios.post('http://localhost:5000/api/signup', signupData);
        console.log('Signup successful:', response.data);
        window.location.replace('/login');
        // Handle success (e.g., redirect to login page, display success message, etc.)
      } catch (error) {
        console.error('There was an error during signup:', error);
        // Handle error (e.g., display error message, etc.)
      }
    };
  
return (
    <div className="signup-container">
      <form className="signup-form" onSubmit={handleSubmit}>
        <h2>Passport Signup</h2>
        <div className="form-group">
          <label htmlFor="username">Username:</label>
          <input
            type="text"
            id="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="signup-button">Sign Up</button>
        <a className='redirect' href="/login">Already a user? Login</a>
      </form>
    </div>
  );
}

export default Signup
