const pool = require("../config/db");

const createApplicationTable = async () => {
  const queryText = `
    CREATE TABLE IF NOT EXISTS applications (
      id SERIAL PRIMARY KEY,
      name VARCHAR(100) NOT NULL,
      dob DATE NOT NULL,
      mobile VARCHAR(20) NOT NULL,
      email VARCHAR(100) NOT NULL,
      aadhar VARCHAR(20) NOT NULL,
      photo BYTEA,
      marksheet BYTEA,
      declaration BOOLEAN NOT NULL
    );
  `;
  await pool.query(queryText);
};

const createApplication = async (applicationData) => {
  const { name, dob, mobile, email, aadhar, photo, marksheet, declaration } =
    applicationData;
  const query = `
    INSERT INTO applications (name, dob, mobile, email, aadhar, photo, marksheet, declaration)
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
    RETURNING *;
  `;
  const values = [
    name,
    dob,
    mobile,
    email,
    aadhar,
    photo,
    marksheet,
    declaration,
  ];

  const { rows } = await pool.query(query, values);
  return rows[0];
};

const getAllCounts = async () => {
  const query = `SELECT
        COUNT(*) AS "all",
        COUNT(CASE WHEN status = 'approved' THEN 1 END) AS approved,
        COUNT(CASE WHEN status = 'rejected' THEN 1 END) AS rejected,
        COUNT(CASE WHEN status = 'processing' THEN 1 END) AS processing
      FROM
        applicationStatus`;
  const { rows } = await pool.query(query);
  return rows;
};

const getAllApplications = async () => {
  const query =
    "SELECT * FROM applicationstatus ast left join applications a on ast.appid=a.id";
  const { rows } = await pool.query(query);
  return rows;
};

const getAllApprovedApplications = async () => {
  const query =
    "SELECT * FROM applicationstatus ast left join applications a on ast.appid=a.id WHERE ast.status = $1";
  const values = ["approved"];
  const { rows } = await pool.query(query, values);
  return rows;
};

const getAllRejectedApplications = async () => {
  const query =
    "SELECT * FROM applicationstatus ast left join applications a on ast.appid=a.id WHERE ast.status = $1";
  const values = ["rejected"];
  const { rows } = await pool.query(query, values);
  return rows;
};

const getAllProcessingApplications = async () => {
  const query =
    "SELECT * FROM applicationstatus ast left join applications a on ast.appid=a.id WHERE ast.status = $1";
  const values = ["processing"];
  const { rows } = await pool.query(query, values);
  return rows;
};

const createPoliceTable = async () => {
  const queryText = `
  CREATE TABLE IF NOT EXISTS Police (
    id SERIAL PRIMARY KEY,
    policename VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    password VARCHAR(200) NOT NULL
  );
  `;
  await pool.query(queryText);
};

// const createPolice = async (applicationData) => {
//   const { name, email, password } =
//     applicationData;
//   const query = `
//     INSERT INTO Police (name, email, password)
//     VALUES ($1, $2, $3)
//     RETURNING *;
//   `;
//   const values = [
//     name,
//     email,
//     password
//   ];

//   const { rows } = await pool.query(query, values);
//   return rows[0];
// };

const createSignUpTable = async () => {
  const queryText = `
  CREATE TABLE IF NOT EXISTS signUpUser (
    id SERIAL PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    password VARCHAR(200) NOT NULL
  );
  `;
  await pool.query(queryText);
};

const signUpInfo = async (signUpInfo) => {
  const { username, email, password } = signUpInfo;
  const query = `
  INSERT INTO signUpUser (username, email, password)
  VALUES ($1, $2, $3)
  RETURNING *;
  `;
  const values = [username, email, password];

  const { rows } = await pool.query(query, values);
  return rows[0];
};

const findUserByEmail = async (email) => {
  const query = `SELECT * FROM signUpUser WHERE email = $1`;
  const { rows } = await pool.query(query, [email]);
  return rows[0];
};

const findPoliceByEmail = async (email) => {
  const query = `SELECT * FROM police WHERE email = $1`;
  const { rows } = await pool.query(query, [email]);
  return rows[0];
};

const createStatusTable = async () => {
  const queryText = `
  CREATE TABLE IF NOT EXISTS applicationStatus (
    id SERIAL PRIMARY KEY,
    appId INT NOT NULL UNIQUE,
    userId INT,
    policeId INT,
    status VARCHAR(50) NOT NULL,
    FOREIGN KEY (appId) REFERENCES applications(id),
    FOREIGN KEY (userId) REFERENCES signupuser(id)
  );
  `;
  await pool.query(queryText);
};

const updateApplicationStatus = async (appId, userId, policeId, status) => {
  let query;
  let values;

  if (userId != '') {
    query = `
    INSERT INTO applicationStatus (appId, userId, status)
    VALUES ($1, $2, $3)
    ON CONFLICT (appId)
    DO UPDATE SET status = EXCLUDED.status
    RETURNING *;
    `;
    values = [appId, userId, status];
  } else if (policeId != '') {
    query = `
    INSERT INTO applicationStatus (appId, policeId, status)
    VALUES ($1, $2, $3)
    ON CONFLICT (appId)
    DO UPDATE SET status = EXCLUDED.status
    RETURNING *;
    `;
    values = [appId, policeId, status];
  } else {
    throw new Error("Either userId or policeId must be provided");
  }

  const { rows } = await pool.query(query, values);
  return rows[0];
};

module.exports = {
  createApplicationTable,
  createApplication,
  getAllApplications,
  createSignUpTable,
  signUpInfo,
  findUserByEmail,
  createPoliceTable,
  findPoliceByEmail,
  createStatusTable,
  updateApplicationStatus,
  getAllApprovedApplications,
  getAllRejectedApplications,
  getAllProcessingApplications,
  getAllCounts,
};
