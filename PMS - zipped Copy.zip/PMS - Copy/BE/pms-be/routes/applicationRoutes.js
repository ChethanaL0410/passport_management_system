const express = require("express");
const router = express.Router();
const multer = require("multer");
const {
  addApplication,
  getApplications,
  signUpData,
  loginData,
  PoliceData,
  approveApplication,
  rejectApplication,
  getApprovedApplications,
  getRejectedApplications,
  getProcessingApplications,
  getCounts,
} = require("../controllers/applicationController");

const storage = multer.memoryStorage(); // Use memory storage to read file data directly
const upload = multer({ storage });

router.post(
  "/applyPassport",
  upload.fields([
    { name: "photo", maxCount: 1 },
    { name: "marksheet", maxCount: 1 },
  ]),
  addApplication
);

router.get("/applications", getApplications); // New route to get all applications
router.get("/counts", getCounts);
router.get("/applications/approved", getApprovedApplications);
router.get("/applications/rejected", getRejectedApplications);
router.get("/applications/processing", getProcessingApplications);

router.post("/signup", signUpData);
router.post("/login", loginData); // Add the login route
router.post("/policelogin", PoliceData);
router.post("/approve", approveApplication);
router.post("/reject", rejectApplication);

module.exports = router;
