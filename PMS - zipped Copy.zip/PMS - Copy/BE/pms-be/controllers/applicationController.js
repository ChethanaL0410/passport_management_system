const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const {
  createApplication,
  getAllApplications,
  signUpInfo,
  findUserByEmail,
  findPoliceByEmail,
  updateApplicationStatus,
  getAllApprovedApplications,
  getAllRejectedApplications,
  getAllProcessingApplications,
  getAllCounts,
} = require("../models/applicationModel");

const addApplication = async (req, res) => {
  const { name, dob, mobile, email, aadhar, declaration, userId } = req.body;
  let photo = null;
  let marksheet = null;

  if (req.files["photo"] && req.files["photo"][0]) {
    photo = req.files["photo"][0].buffer; // Use buffer directly
  }

  if (req.files["marksheet"] && req.files["marksheet"][0]) {
    marksheet = req.files["marksheet"][0].buffer; // Use buffer directly
  }

  const applicationData = {
    name,
    dob,
    mobile,
    email,
    aadhar,
    photo,
    marksheet,
    declaration: declaration === "true",
    userId,
  };

  try {
    const newApplication = await createApplication(applicationData);
    console.log("newapplication" + JSON.stringify(newApplication.id));
    const result = await updateApplicationStatus(
      newApplication.id,
      userId,
      '',
      "processing"
    );
    res.status(201).json(newApplication);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

const getApplications = async (req, res) => {
  try {
    const applications = await getAllApplications();
    res.status(200).json(applications);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

const getCounts = async (req, res) => {
  try {
    const countapplications = await getAllCounts();
    res.status(200).json(countapplications);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

const getApprovedApplications = async (req, res) => {
  try {
    const approvedapplications = await getAllApprovedApplications();
    res.status(200).json(approvedapplications);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

const getRejectedApplications = async (req, res) => {
  try {
    const rejectedapplications = await getAllRejectedApplications();
    res.status(200).json(rejectedapplications);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

const getProcessingApplications = async (req, res) => {
  try {
    const processingapplications = await getAllProcessingApplications();
    res.status(200).json(processingapplications);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

const signUpData = async (req, res) => {
  const { username, email, password } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10); // Hash the password
  const signUpDetails = { username, email, password: hashedPassword };
  try {
    const newsignUpInfo = await signUpInfo(signUpDetails);
    res.status(200).json(newsignUpInfo);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

const loginData = async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await findUserByEmail(email);
    if (!user) {
      return res.status(400).json({ message: "User not found" });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET, {
      expiresIn: "1h",
    });
    res.status(200).json({ userId: user.id, token });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

const PoliceData = async (req, res) => {
  const { email, password } = req.body;
  try {
    const police = await findPoliceByEmail(email);
    if (!police) {
      return res.status(400).json({ message: "Police not found" });
    }

    // const isMatch = await bcrypt.compare(password, police.password);
    // if (!isMatch) {
    //   return res.status(400).json({ message: 'Invalid credentials' });
    // }

    if (password != police.password) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const token = jwt.sign({ PoliceId: police.id }, process.env.JWT_SECRET, {
      expiresIn: "1h",
    });
    res.status(200).json({ policeId: police.id, token: token });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

const approveApplication = async (req, res) => {
  const { appId, policeId } = req.body;
  try {
    const result = await updateApplicationStatus(
      appId,
      '',
      policeId,
      "approved"
    );
    res.status(200).json(result);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

const rejectApplication = async (req, res) => {
  const { appId, policeId } = req.body;

  try {
    const result = await updateApplicationStatus(
      appId,
      '',
      policeId,
      "rejected"
    );
    res.status(200).json(result);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = {
  addApplication,
  getApplications,
  signUpData,
  loginData,
  PoliceData,
  approveApplication,
  rejectApplication,
  getApprovedApplications,
  getRejectedApplications,
  getProcessingApplications,
  getCounts,
};
